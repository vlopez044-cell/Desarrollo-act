// Array con las imágenes
const imagenes = [
  "https://images.unsplash.com/photo-1503756234508-e32369269deb?q=80&w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1548032885-b5e38734688a?q=80&w=400&h=300&fit=crop",
  "https://images.unsplash.com/photo-1499202189329-5d76e29aa2b6?q=80&w=400&h=300&fit=crop",
  "https://plus.unsplash.com/premium_photo-1754269293276-4f00cdec2aab?q=80&w=400&h=300&fit=crop",
  "https://plus.unsplash.com/premium_photo-1667149988086-faabd5a500b3?q=80&w=400&h=300&fit=crop"
];

// Selección de elementos
const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

// Contador de imágenes
let indice = 0;

// Evento del click
boton.addEventListener("click", () => {
  // Avanzar al siguiente índice y volver al inicio si es necesario
  indice = (indice + 1) % imagenes.length;
  
  // Cambiar imagen y texto
  imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});

