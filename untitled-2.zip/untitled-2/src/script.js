//desafio 1 getElementById//

document.getElementById("btn-titulo").addEventListener("click",()=>
                                                                                     {
  const titulo = document.getElementById("titulo");
titulo.textContent= "¡Valeria López!";
     }
 );